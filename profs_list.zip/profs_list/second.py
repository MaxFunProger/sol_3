from flask import Flask
from flask import render_template


app = Flask(__name__)


@app.route('/list_prof/<list>')
def profs(list):
    list_prof = ['инженер-исследователь', 'пилот', 'штурман', 'врач',
                 'экзобиолог', 'программист', 'оператор дрона',
                 'гипнатизер инопланетян', 'метеоролог', 'киберинженер',
                 'садовник', 'главный инженер', 'повар']
    return render_template('list.html', list=list, list_prof=list_prof)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
